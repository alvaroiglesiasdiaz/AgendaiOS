//
//  CumtomCell.swift
//  ListView
//
//  Created by Apps2t on 16/10/2020.
//  Copyright © 2020 CEV. All rights reserved.
//

import UIKit

class CumtomCell: UITableViewCell {

    @IBOutlet weak var customView: UIView!
    @IBOutlet weak var movieImage: UIImageView!
    @IBOutlet weak var movieTitleLB: UILabel!
    
    
   

    /* @IBOutlet weak var movieImage: UIImageView!
    
    @IBOutlet weak var movieTitleLB: UILabel!*/
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
