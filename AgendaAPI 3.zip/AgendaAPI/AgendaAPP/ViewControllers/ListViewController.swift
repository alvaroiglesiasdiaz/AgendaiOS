//
//  ViewController.swift
//  AgendaAPP
//
//  Created by user177270 on 3/1/21.
//

import UIKit

class ListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
   
    @IBOutlet weak var tableView: UITableView!
    //URL para obtener lista completa de contactos
   
    @IBAction func BTNAddContact(_ sender: Any) {
        showAlert()
    }
    
    
    
    var index = 0
    var array:[Contact] = []
    let contacts = [
    "User 1",
    "User 2",
    "User 3",
    "User 4",
    "User 5",
    "User 6",
    "User 7"
    ]
    
    override func viewWillAppear(_ animated: Bool) {
        
           printContactList()
           
       }
    func printContactList(){
       // NetworkManager.shared.contactList(email: <#T##String#>, completionHandler: <#T##(Bool) -> Void#>)
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell"/*, for: indexPath*/) as! CumtomCell
        
        cell.LBContactName.text = self.contacts[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //tableView.deselectRow(at: indexPath, animated: true)
        index = indexPath.row
        performSegue(withIdentifier: "segue2", sender: self)
        
        
    }
    
     
    func numberOfSections(in tableView: UITableView) -> Int {

        return 1

    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "segue2"{
                
                if let indexPath = tableView.indexPathForSelectedRow{
                    
                    let destinationVC = segue.destination as!  SettingsViewController
                    destinationVC.contactName = contacts[indexPath.row]
                  
                }
            }
                
        }
        
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
            tableView.delegate = self
            tableView.dataSource = self
            //NetworkManager.shared.contactList(email: "alvaro@gmail.com")
    }
    func showAlert(){
            //la variable alert va a mostrar un dialogo en pantalla
            let alert = UIAlertController(title: "New contact", message: "Set a name for your new contact", preferredStyle: .alert)
            //aqui añado las acciones que  van a tener ambos botones del alert como variables
        let action = UIAlertAction(title: "Contact name", style: .default) { (alertAction) in
          let textField = alert.textFields![0] as UITextField
        
            if(textField.text != ""){
               
                    
                   // NetworkManager.shared.addUser(name: textField.text!)
                
                
            }
        
        }
        alert.addTextField { (textField) in
        textField.placeholder = "Enter name"
        }
        
        alert.addAction(action)
     
        self.present(alert, animated: true, completion: nil)

        }

}

