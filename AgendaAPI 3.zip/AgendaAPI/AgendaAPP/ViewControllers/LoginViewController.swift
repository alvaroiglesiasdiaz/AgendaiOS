//
//  ViewController.swift
//  AgendaAPP
//
//  Created by user177270 on 3/1/21.
//

import UIKit

class LoginViewController: UIViewController{
    
    @IBOutlet weak var TFEmail: UITextField?
    @IBOutlet weak var TFPassword: UITextField?
    @IBAction func BTNLogin(_ sender: Any) {
        
        if (TFEmail?.text == "" || TFPassword?.text == ""){
            
            showAlert()
        }else{
            NetworkManager.shared.userLogin(email: (TFEmail?.text)!, password: (TFPassword?.text)!, completionHandler: { [self]
                success in
                
                print("Login request sent")
                
                if success{
                    
                    print("Login success")
                    
                    //Ejecutar segue de manera sincrona
                    DispatchQueue.global().sync {
                        do{
                            let defaults = UserDefaults.standard
                            
                            let token = defaults.object(forKey: "token")!
                            
                            print ("User token: ",token)
                            
                            let dataToken = defaults.string(forKey: "token")
                            //Segue to contact list view
                            self.performSegue(withIdentifier: "loginToList", sender: self)

                        }catch {
                            
                            }
                    }
                    
                }else{
                    
                    print("Request error")
                    //If login fails then show alert
                   showAlert()
                }
            })

        }
        

            }
   
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Set circular corners
        //BTNLogin.layer.cornerRadius = 20.0
        TFEmail?.layer.cornerRadius = 25.0
        TFPassword?.layer.cornerRadius = 25.0
        TFEmail?.layer.borderColor = UIColor.black.cgColor
        TFPassword?.layer.borderColor = UIColor.black.cgColor

        
    }

    
    func showAlert(){
            //la variable alert va a mostrar un dialogo en pantalla y toma 3 argumentos, el titulo. la descripcion y el estilo
            let alert = UIAlertController(title: "Login failed", message: "Email or pasword incorrect or missing", preferredStyle: .alert)
            
            //aqui añado las acciones que  van a tener ambos botones del alert como variables
            let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
                
            })
            
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
            
        }
}

