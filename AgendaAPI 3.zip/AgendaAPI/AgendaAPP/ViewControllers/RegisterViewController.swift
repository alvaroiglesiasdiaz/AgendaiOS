//
//  RegisterViewController.swift
//  AgendaAPP
//
//  Created by user177270 on 3/7/21.
//

import UIKit

class RegisterViewController: UIViewController{
  
    @IBOutlet weak var TFEmail: UITextField!
    
    
    @IBOutlet weak var TFPassword: UITextField!
    @IBOutlet weak var TFRepeatPass: UITextField!
    
    @IBAction func BTNResgiter(_ sender: Any) {
        if (TFEmail?.text == "" || TFPassword?.text == "" || TFRepeatPass?.text == nil){
                   
                   showAlertEmpty()
               }
        if (TFPassword.text != TFRepeatPass.text) {
            showAlertPassMatch()
            
        }
        else{
          //  NetworkManager.shared.userRegister(email: TFEmail.text!, password: TFPassword.text!, repeatPass: TFRepeatPass.text!)

                   performSegue(withIdentifier: "registerToLogin", sender: self)
               }
        
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Set circular corners
        //BTNLogin.layer.cornerRadius = 20.0
        TFEmail?.layer.cornerRadius = 25.0
        TFPassword?.layer.cornerRadius = 25.0
        TFEmail?.layer.borderColor = UIColor.black.cgColor
        TFPassword?.layer.borderColor = UIColor.black.cgColor

        
    }

    
    func showAlertEmpty(){
            //la variable alert va a mostrar un dialogo en pantalla y toma 3 argumentos, el titulo. la descripcion y el estilo
            let alert = UIAlertController(title: "Registration failed", message: "Email or password incorrect or missing, please try again", preferredStyle: .alert)
            //aqui añado las acciones que  van a tener ambos botones del alert como variables
            let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
            })
            
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
            
        }
    func showAlertPassMatch(){
            //la variable alert va a mostrar un dialogo en pantalla y toma 3 argumentos, el titulo. la descripcion y el estilo
            let alert = UIAlertController(title: "Credentials error", message: "Your passwords don't match", preferredStyle: .alert)
            //aqui añado las acciones que  van a tener ambos botones del alert como variables
            let ok = UIAlertAction(title: "Try again", style: .default, handler: { (action) -> Void in
            })
            
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
            
        }
}

