//
//  NetworkManager.swift
//  AgendaAPP
//
//  Created by Apps2t on 02/03/2021.
//
// h ttps://www.youtube.com/watch?v=OQ6wm1QQPWA
import Foundation
import Alamofire

class NetworkManager {
    
    static var shared: NetworkManager = NetworkManager()
    //Funcion loguear usuario
    func userLogin(email: String, password: String){
        
        struct Login: Encodable{
            
            public let email: String
            public let password: String
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let loginParams: [String:Any] = ["email": email , "password": password]
        print(loginParams)
        let loginRequest = try? JSONSerialization.data(withJSONObject: loginParams)
        //Create Alamofire request to API
    
        var requestLogin = URLRequest(url: url)
        requestLogin.httpMethod = "GET"
        requestLogin.httpBody = loginRequest
        requestLogin.headers = ["Content-Type": "application/json"]
        
        AF.request(requestLogin ).responseJSON{ response in
                    
            debugPrint(response.data)
                 }
    }
    //Registrar un nuevo usuario a la app
    func userRegister(email: String, password: String, repeatPass: String){
        
        struct Register: Encodable{
            
            public let email: String
            public let password: String
            public let repeatPass: String
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let registerParams: [String:Any] = ["email": email , "password": password, "repeatPass": repeatPass]
        print(registerParams)
        let registerRequest = try? JSONSerialization.data(withJSONObject: registerParams)
        
        //Create Alamofire request to API
    
        var requestRegister = URLRequest(url: url)
        requestRegister.httpMethod = "POST"
        requestRegister.httpBody = registerRequest
        requestRegister.headers = ["Content-Type": "application/json"]
        
        AF.request(requestRegister).responseJSON{ response in
                    
            debugPrint(response)
                 }
    }
    //Se envia el email y si coincide con el de la base de datos se envia un email al usuario con la contrasena
    func passRecover(email: String){
        
        struct Recover: Encodable{
            
            public let email: String
           
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let recoverParams: [String:Any] = ["email": email ]
        print(recoverParams)
        let recoverRequest = try? JSONSerialization.data(withJSONObject: recoverParams)
        
        //Create Alamofire request to API
    
        var requestRecover = URLRequest(url: url)
        requestRecover.httpMethod = "GET"
        requestRecover.httpBody = recoverRequest
        requestRecover.headers = ["Content-Type": "application/json"]
        
        AF.request(requestRecover).responseJSON{ response in
                    
            debugPrint(response)
            
                 }
        
    }
    
    //Se imprime una lista con todos los contactos para poder mostrarlos en la tabla
    func contactList(email: String){
        
        
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        
        //Create Alamofire request to API
    
        var requestRecover = URLRequest(url: url)
        requestRecover.httpMethod = "GET"
        requestRecover.headers = ["Content-Type": "application/json"]
        AF.request(requestRecover).responseJSON{response in
                    
            debugPrint(response.data)
                 }
    }
  
    //Funcion para anadir nuevo contacto del usuario
    func addUser(name: String){
        
        struct Add: Encodable{
            
            public let name: String
           
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let createParams: [String:Any] = ["name": name ]
        print(createParams)
        let createRequest = try? JSONSerialization.data(withJSONObject: createParams)
        
        //Create Alamofire request to API
    
        var requestCreate = URLRequest(url: url)
        requestCreate.httpMethod = "POST"
        requestCreate.httpBody = createRequest
        requestCreate.headers = ["Content-Type": "application/json"]
        
        AF.request(requestCreate).responseJSON{ response in
                    
            debugPrint(response)
                 }
    }
    //Edit nombre del contacto seleccionado
    func editUser(name: String){
        
        struct Add: Encodable{
            
            public let name: String
           
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let editParams: [String:Any] = ["name": name ]
        print(editParams)
        let editRequest = try? JSONSerialization.data(withJSONObject: editParams)
        
        //Create Alamofire request to API
    
        var requestEdit = URLRequest(url: url)
        requestEdit.httpMethod = "POST"
        requestEdit.httpBody = editRequest
        requestEdit.headers = ["Content-Type": "application/json"]
        
        AF.request(requestEdit).responseJSON{ response in
                    
            debugPrint(response)
        }
    }
    //Se borra el contacto seleccionado de la lista
    func deleteAccount(name: String){
        
        struct Recover: Encodable{
            
            public let name: String
           
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let recoverParams: [String:Any] = ["name": name ]
        print(recoverParams)
        let recoverRequest = try? JSONSerialization.data(withJSONObject: recoverParams)
        
        //Create Alamofire request to API
    
        var requestRecover = URLRequest(url: url)
        requestRecover.httpMethod = "GET"
        requestRecover.httpBody = recoverRequest
        requestRecover.headers = ["Content-Type": "application/json"]
        
        AF.request(requestRecover).responseJSON{ response in
                    
            debugPrint(response)
                 }
    }
    
    func editPassword(password: String){
        
        struct Add: Encodable{
            
            public let name: String
           
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let editParams: [String:Any] = ["password": password ]
        print(editParams)
        let editRequest = try? JSONSerialization.data(withJSONObject: editParams)
        
        //Create Alamofire request to API
    
        var requestEdit = URLRequest(url: url)
        requestEdit.httpMethod = "POST"
        requestEdit.httpBody = editRequest
        requestEdit.headers = ["Content-Type": "application/json"]
        
        AF.request(requestEdit).responseJSON{ response in
                    
            debugPrint(response)
        }
    }
    //Se borra el contacto seleccionado de la lista
    func deleteProfile(name: String){
        
        struct Recover: Encodable{
            
            public let name: String
           
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let recoverParams: [String:Any] = ["name": name ]
        print(recoverParams)
        let recoverRequest = try? JSONSerialization.data(withJSONObject: recoverParams)
        
        //Create Alamofire request to API
    
        var requestRecover = URLRequest(url: url)
        requestRecover.httpMethod = "GET"
        requestRecover.httpBody = recoverRequest
        requestRecover.headers = ["Content-Type": "application/json"]
        
        AF.request(requestRecover).responseJSON{ response in
                    
            debugPrint(response)
                 }
    }
}
