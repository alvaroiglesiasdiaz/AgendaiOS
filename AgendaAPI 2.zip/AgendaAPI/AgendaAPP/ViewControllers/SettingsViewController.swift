//
//  SettingsViewController.swift
//  AgendaAPP
//
//  Created by Apps2t on 03/03/2021.
//

import UIKit

class SettingsViewController: UIViewController {
    
    
    @IBOutlet weak var LBContactName: UILabel!
    var contactName: String?
    
    @IBAction func BTNDeleteContact(_ sender: Any) {
        showAlertDelete()
        
    }
    @IBAction func BTNModifyContact(_ sender: Any) {
        showAlertModify()
    }
    override func viewDidLoad() {
           super.viewDidLoad()
           
              
        
       }
    override func viewDidAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
              
              if let contactName = contactName {
                  LBContactName.text = contactName
                  
              }
    }
    
    func showAlertModify(){
            //la variable alert va a mostrar un dialogo en pantalla
            let alert = UIAlertController(title: "Edit contact", message: "Set a new  contact name", preferredStyle: .alert)
            
        let action = UIAlertAction(title: "Change name", style: .default) { (alertAction) in
          let textField = alert.textFields![0] as UITextField
        
            if(textField.text != ""){
               
                    
                NetworkManager.shared.editUser(name: textField.text!)
                
                
            }
        
        }
        alert.addTextField { (textField) in
        textField.placeholder = "Enter new name"
        }
        
        alert.addAction(action)
     
        self.present(alert, animated: true, completion: nil)

        }
    
    func showAlertDelete(){
            
        let alert = UIAlertController(title: "Delete account", message: "Are you sure you want to delete your account?" ,preferredStyle: .alert)
            
            //aqui añado las acciones que  van a tener ambos botones del alert como variables
        let ok = UIAlertAction(title: "Yes, delete it", style: .default, handler: { [self] (action) -> Void in
                NetworkManager.shared.deleteAccount(name: contactName!)
            })
            
            let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (action) -> Void in
                print("Cancel button tapped")}
            
            alert.addAction(ok)
            alert.addAction(cancel)
      
            self.present(alert, animated: true, completion: nil)
            
        }
    }
