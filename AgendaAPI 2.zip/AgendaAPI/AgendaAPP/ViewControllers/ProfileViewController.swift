//
//  SettingsViewController.swift
//  AgendaAPP
//
//  Created by Apps2t on 03/03/2021.
//

import UIKit

class ProfileViewController: UIViewController {
    
    
    
    @IBAction func BTNDeleteContact(_ sender: Any) {        showAlertDelete()
        
    }
    @IBAction func BTNChangePassword(_ sender: Any) {
        showAlertEdit()
    }
    override func viewDidLoad() {
           super.viewDidLoad()
           
              
        
       }
    override func viewDidAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
              
             
              }
    
    
    func showAlertEdit(){
            //la variable alert va a mostrar un dialogo en pantalla
            let alert = UIAlertController(title: "Change password", message: "Set a new  password", preferredStyle: .alert)
            
        let action = UIAlertAction(title: "Change password", style: .default) { (alertAction) in
          let textField = alert.textFields![0] as UITextField
        
            if(textField.text != ""){
               
                NetworkManager.shared.editPassword(password: textField.text!)
                
            }
        
        }
        alert.addTextField { (textField) in
        textField.placeholder = "Enter new password"
        }
        
        alert.addAction(action)
     
        self.present(alert, animated: true, completion: nil)
        }
    
    func showAlertDelete(){
            
        let alert = UIAlertController(title: "Delete profile", message: "Are you sure you want to delete your account?" ,preferredStyle: .alert)
            
            //aqui añado las acciones que  van a tener ambos botones del alert como variables
        let ok = UIAlertAction(title: "Yes, delete it", style: .default, handler: {(action) -> Void in
            //Se le pasa el nombre del usuario para borrarlo de la base de datos
            NetworkManager.shared.deleteProfile(name: "User name")
            })
            
            let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (action) -> Void in
                print("Cancel button tapped")}
            
            alert.addAction(ok)
            alert.addAction(cancel)
      
        self.present(alert, animated: true, completion: nil)
            
        }
    }
